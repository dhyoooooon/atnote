package kr.ac.afa.atnote;

/**
 * Created by YOONDH on 2018-04-29.
 */

public class WhereInfoActivity {
}
